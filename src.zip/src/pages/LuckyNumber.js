import React, { useState } from 'react';
import "./css/slots.css";

const LuckyNumber = () => {
    // Prompt user for a number between 1-50
    let userNumber = parseInt(prompt("Choose a number between 1 and 50:"));

    // Generate a random number between 1-50
    let randomNumber = Math.floor(Math.random() * 50) + 1;
  };

  return (
    <header className="App-header">
      <h1>LUCKY NUMBER GAME</h1>
      <body>
        <div>
        </div>
      </body>
    </header>
  );
};

export default LuckyNumber;